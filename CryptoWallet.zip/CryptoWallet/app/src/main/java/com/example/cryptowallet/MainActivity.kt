package com.example.cryptowallet

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cryptowallet.adapter.CategoryAdapter
import com.example.cryptowallet.model.Category
import android.content.Context
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.widget.TextView
import java.util.*



class MainActivity : AppCompatActivity() {
    lateinit var categoryRecycler: RecyclerView
    lateinit var categoryAdapter: CategoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val categoryList = mutableListOf<Category>().apply {
            add(Category(1, "Баланс"))
            add(Category(2, "Купить"))
            add(Category(3, "Отправить"))
        }

        setCategoryRecycler(categoryList)
    }

    private fun setCategoryRecycler(categoryList: List<Category>) {
        categoryRecycler = findViewById(R.id.categoryRecycler)
        categoryRecycler.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        categoryAdapter = CategoryAdapter(this, categoryList)
        categoryRecycler.adapter = categoryAdapter
    }
}

class RegistrationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registration_activity)

        val usernameEditText = findViewById<EditText>(R.id.username)
        val passwordEditText = findViewById<EditText>(R.id.password)
        val confirmPasswordEditText = findViewById<EditText>(R.id.confirm_password)
        val nextButton = findViewById<Button>(R.id.next_button)

        nextButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()
            val confirmPassword = confirmPasswordEditText.text.toString()

            if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show()
            } else if (!username.matches(Regex("^[a-zA-Z]*$"))) {
                Toast.makeText(this, "Username must contain only English letters", Toast.LENGTH_SHORT).show()
            } else if (password.length < 6) {
                Toast.makeText(this, "Password must be at least 6 characters long", Toast.LENGTH_SHORT).show()
            } else if (password != confirmPassword) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
            } else {
                // Сохраняем данные пользователя
                val sharedPref = getSharedPreferences("CryptoWallet", Context.MODE_PRIVATE)
                with (sharedPref.edit()) {
                    putString("username", username)
                    putString("password", password)
                    apply()
                }

                // Переходим к следующему экрану
                val intent = Intent(this, SeedActivity::class.java)
                startActivity(intent)
            }
        }
    }
}

class SeedActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.seed_activity)

        val seedWords = arrayOfNulls<TextView>(12)
        seedWords[0] = findViewById(R.id.seed_word_1)
        // Инициализируйте остальные TextView для слов сид-фразы

        val signUpButton = findViewById<Button>(R.id.sign_up_button)

        // Генерируем случайные слова для сид-фразы
        val randomWords = generateRandomWords(12)
        for (i in 0..11) {
            seedWords[i]?.text = randomWords[i]
        }

        signUpButton.setOnClickListener {
            // Переходим к следующему экрану
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
    }

    private fun generateRandomWords(count: Int): List<String> {
        val words = listOf("apple", "banana", "cherry", "date", "elderberry", "fig", "grape", "honeydew", "iceberg", "jackfruit", "kiwi", "lemon", "mango", "nectarine", "orange", "pineapple", "quince", "raspberry", "strawberry", "tangerine", "ugli", "victoria", "watermelon", "xigua", "yellow", "zucchini")
        return List(count) { words[Random().nextInt(words.size)] }
    }
}


class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profile_activity)

        val nameEditText = findViewById<EditText>(R.id.name)
        val ageEditText = findViewById<EditText>(R.id.age)
        val nextButton = findViewById<Button>(R.id.next_button)
        val skipButton = findViewById<Button>(R.id.skip_button)

        nextButton.setOnClickListener {
            // Сохраняем данные пользователя
            val sharedPref = getSharedPreferences("CryptoWallet", Context.MODE_PRIVATE)
            with (sharedPref.edit()) {
                putString("name", nameEditText.text.toString())
                putInt("age", ageEditText.text.toString().toIntOrNull() ?: 0)
                apply()
            }

            // Переходим к следующему экрану
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        skipButton.setOnClickListener {
            // Переходим к следующему экрану без сохранения данных
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_activity)

        val usernameEditText = findViewById<EditText>(R.id.username)
        val passwordEditText = findViewById<EditText>(R.id.password)
        val signInButton = findViewById<Button>(R.id.sign_in_button)

        signInButton.setOnClickListener {
            // Получаем данные пользователя
            val sharedPref = getSharedPreferences("CryptoWallet", Context.MODE_PRIVATE)
            val savedUsername = sharedPref.getString("username", "")
            val savedPassword = sharedPref.getString("password", "")

            val enteredUsername = usernameEditText.text.toString()
            val enteredPassword = passwordEditText.text.toString()

            if (enteredUsername == savedUsername && enteredPassword == savedPassword) {
                // Переходим к следующему экрану
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            } else {
                // Показываем сообщение об ошибке
                Toast.makeText(this, "Invalid login or password", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

class BalanceActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.balance_activity)
    }
}

class SendActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.send_activity)
    }
}

class BuyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.buy_activity)
    }
}